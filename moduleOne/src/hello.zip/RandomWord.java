import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdRandom;

class RandomWord {
    public static void main(String[] args) {

        double p = 0.5;

        while (!StdIn.isEmpty()) {
            String word = StdIn.readString();
            if (StdRandom.bernoulli(p)){
                System.out.println(word);
            }
        }

    }
}
